package Entity;

public class Door extends Body {
    
}
