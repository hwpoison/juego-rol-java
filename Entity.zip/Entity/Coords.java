package Entity;

public class Coords {
   public int x;
   public int y; 
}
